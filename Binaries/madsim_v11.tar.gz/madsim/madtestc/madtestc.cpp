//============================================================================
// Name        : madtestc.cpp
// Author      : htf
// Version     :
// Copyright   : (c) 2021
// Description : Hello World in C++, Ansi-style
//============================================================================

#undef BIO
#include "../madtest/madtest.cpp"
